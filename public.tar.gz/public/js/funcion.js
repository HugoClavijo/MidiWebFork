
        $(document).ready(function(){
            console.log("Script working properly");
        });
        
        $("#tagline").click(function(){
            alert("The paragraph was clicked.");
        });
    